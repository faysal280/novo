$(document).ready(function () {
    

   
$('#vfindbtn').on('click', function(e){
e.preventDefault();

var cname=$('#cname').val();

$.ajax({
    type: "get",
    url: "https://api.sharetrip.net/api/v1/visa/visa-guide",
    data: {name:cname},
    success: function (res) {
        const data=res.response;
        $('#capital').text(data.capital);
        $('#ltime').text(data.localTime);
        $('#tcode').text(data.telephoneCode);
        $('#btime').text(data.bankTime);
        $('#erate').text(data.exchangeRate);
        $('#eadress').text(data.embassyAddress);
        $('#cmap').attr('src',data.countryImage);
        $('.visainformationdiv').html(data.visaRequirmentDescription);
        
        window.location.href="#vrsearch";
    
    }
});

});

});





